#include <stddef.h>
#include "numquad.h"

double numquad(double (*f)(double), double a, double b, size_t n) {
    // Implement the function here
    return 0.0;
}
