#include <iostream>


class A {
public:
    A () {
        std::cout << "A created" << std::endl;
    }

    A (int x) {
        std::cout << "A created with " << x << std::endl;
    }
};



class B {
    int x;
    A a;
   
public:
    B (A a){ 
        this->a = a;
    }

};

int main() {
    A a(5);

    B b = B{a};

}
