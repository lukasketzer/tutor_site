#include <iostream>

class Player {
public:
    int health;
    Player(int health):health(health) {
    }
    
};

void attack(Player &p) {
    p.health -= 1;
}

int main() {
    Player p = Player{5};
    std::cout << "vor attack(): " <<p.health << std::endl;
    attack(p);
    std::cout << "nach attack(): " <<p.health << std::endl;


}
